-- incorrect float
funcao arg1 arg2 = statement -123.e

funcao arg1 =
    statement -1234.$123e-123

main = do $a
    print a'
    'ads'
