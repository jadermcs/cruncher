funcao arg1 arg2 = statement -123.

funcao arg1 arg2 arg3 = statement -123

funcao arg1 =
    statement -1234.123e-123

-- a very long comment with 1283(*&$&@$!&@#.zx;a;sd 4 12 éćstrange things

main = do $
    a <- [1..60], n <- [1..60], mod (poly m n) 60 == k ]
    print a
