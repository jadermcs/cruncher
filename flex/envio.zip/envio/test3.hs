main = printLn "alo


func arg1 = arg2 1
