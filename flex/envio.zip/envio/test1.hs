funcao :: a -> a
funcao = id

funcao :: Integer -> Integer
funcao arg1 = add arg1 23

main = printLn "Hello World!"
